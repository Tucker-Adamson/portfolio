module.exports = {
  devServer: {
    host: 'localhost',
    port: 8080
  }
};

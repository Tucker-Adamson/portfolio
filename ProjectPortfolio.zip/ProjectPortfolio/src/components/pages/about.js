import React from 'react';
import profilePicture from "../../../static/assets/images/bio/profile.png"

export default function() {
    return (
        <div className="content-page-wrapper">
            <div 
            className="left-column"
            style={{
                background: "url(" + profilePicture + ") no-repeat",
                backgroundSize: "cover",
                backgroundPosition: "center",
            }}
            />
            <div className="right-column"> 
                <p>lh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl hlh uih iu h iuh i uhi uh iuh iu hiu h iuh iuh  uhi h ih i uh iuh u 
                    hiu hi h iuh iu hiu h liuh iuh u hli hiu h uhu u hu hu hi uh uh iuh
                    liu hli h ih iu hiu h liuh iu h ih  lh hu h ilu hi h iuh iu hi uh
                    ilh il h lih liu hliu h iuh iuh iul hi uh iuh iluh iu h iuh uh uh
                    uh lih liu hi uh uh uh uh uh lh uh luh luh lu h luh uh uh luih
                    iuh u huh uh u h uh uh uh uh hu uhl uhl h</p> 
            </div>
        </div>
    );
}
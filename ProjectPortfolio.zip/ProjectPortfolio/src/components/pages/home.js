import React from 'react';

import PortfolioContainer from '../portfolio/portfolio-container';

export default function() {
    return (
        <div>
            <PortfolioContainer />
        </div>
    );
}
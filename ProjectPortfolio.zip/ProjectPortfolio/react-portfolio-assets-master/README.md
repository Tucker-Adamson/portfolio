# Asset Repository

![logo](https://s3.amazonaws.com/bottega-devcamp/bottega-devcamp.png)

> This repo contains the starter assets for the [Bottega Code School](https://bottega.tech) Dissecting React track. These files should be used as templates for your own portfolio.
